kills all processes not in C:\Windows\System32\ for a quick performance boost.
