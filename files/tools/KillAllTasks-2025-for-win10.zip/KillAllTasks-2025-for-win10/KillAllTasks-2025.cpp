// Compiled with 32-bit TDM-GCC 4.9.2 in Dev-C++
// Arguments: -std=c++11 -lpsapi

#include <windows.h>
#include <tlhelp32.h>
#include <iostream>
#include <vector>
#include <string>
#include <psapi.h>
#include <algorithm>
#include <cctype>

#pragma comment(lib, "psapi.lib")

bool EnableDebugPrivilege() {
    HANDLE hToken;
    TOKEN_PRIVILEGES tokenPrivileges;

    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
        return false;
    }

    LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &tokenPrivileges.Privileges[0].Luid);
    tokenPrivileges.PrivilegeCount = 1;
    tokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    if (!AdjustTokenPrivileges(hToken, FALSE, &tokenPrivileges, sizeof(TOKEN_PRIVILEGES), NULL, NULL)) {
        CloseHandle(hToken);
        return false;
    }

    CloseHandle(hToken);
    return GetLastError() == ERROR_SUCCESS;
}

void EnsureAdminPrivileges() {
    BOOL isElevated = FALSE;
    HANDLE hToken = NULL;

    if (OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        TOKEN_ELEVATION elevation;
        DWORD size;
        if (GetTokenInformation(hToken, TokenElevation, &elevation, sizeof(elevation), &size)) {
            isElevated = elevation.TokenIsElevated;
        }
        CloseHandle(hToken);
    }

    if (!isElevated) {
        wchar_t exePath[MAX_PATH];
        GetModuleFileNameW(NULL, exePath, MAX_PATH);

        SHELLEXECUTEINFOW sei = { sizeof(SHELLEXECUTEINFOW) };
        sei.lpVerb = L"runas";
        sei.lpFile = exePath;
        sei.nShow = SW_SHOWNORMAL;

        if (!ShellExecuteExW(&sei)) {
            std::wcerr << L"Failed to elevate process to admin. Exiting.\n";
            exit(EXIT_FAILURE);
        }
        exit(EXIT_SUCCESS);
    }
}

bool IsInWindowsDirectory(const std::wstring& path) {
    std::wstring windowsDir = L"C:\\Windows\\System32\\";
    std::wstring normalizedPath = path;

    // Normalize to lowercase
    std::transform(windowsDir.begin(), windowsDir.end(), windowsDir.begin(), ::towlower);
    std::transform(normalizedPath.begin(), normalizedPath.end(), normalizedPath.begin(), ::towlower);

    // Check if the path starts with "C:\Windows\System32\"
    return normalizedPath.find(windowsDir) == 0;
}

void KillAllTasks() {
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        std::cerr << "Failed to create process snapshot." << std::endl;
        return;
    }

    PROCESSENTRY32 pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32);

    if (Process32First(hSnapshot, &pe32)) {
        int successCount = 0;
        int ignoredCount = 0;
        int failResolveCount = 0;
        int failKillCount = 0;

        do {
            std::wstring processName(pe32.szExeFile, pe32.szExeFile + strlen(pe32.szExeFile));
            std::wstring processPath;

            HANDLE hProcess = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_TERMINATE, FALSE, pe32.th32ProcessID);
            if (hProcess) {
                wchar_t pathBuffer[MAX_PATH];
                if (GetModuleFileNameExW(hProcess, NULL, pathBuffer, MAX_PATH)) {
                    processPath = pathBuffer;
                } else {
                    failResolveCount++;
                }

                if (!processPath.empty() && IsInWindowsDirectory(processPath)) {
                    ignoredCount++;
                } else if (!processPath.empty()) {
                    if (TerminateProcess(hProcess, 0)) {
                        std::wcout << L"> Killed: " << processName << L" (" << processPath << L")" << std::endl;
                        successCount++;
                    } else {
                        failKillCount++;
                    }
                }

                CloseHandle(hProcess);
            } else {
                failResolveCount++;
            }

        } while (Process32Next(hSnapshot, &pe32));

        std::cout << "\nSummary:\n";
        std::cout << "Killed " << successCount << " tasks." << std::endl;
        std::cout << "Ignored " << ignoredCount << " safe tasks." << std::endl;
        if (failKillCount > 0) {
            std::cout << "Failed to kill " << failKillCount << " tasks." << std::endl;
        }
        if (failResolveCount > 0) {
            std::cout << "Failed to resolve " << failResolveCount << " tasks." << std::endl;
        }
    }

    CloseHandle(hSnapshot);
}

int main() {
    SetConsoleTitleW(L"KillAllTasks by SmilerRyan");
    std::wcout << L"KillAllTasks By SmilerRyan\n\n";

    EnsureAdminPrivileges();
    if (!EnableDebugPrivilege()) {
        std::cerr << "Failed to enable debug privilege." << std::endl;
        return EXIT_FAILURE;
    }

    KillAllTasks();
    system("pause");

    return 0;
}
